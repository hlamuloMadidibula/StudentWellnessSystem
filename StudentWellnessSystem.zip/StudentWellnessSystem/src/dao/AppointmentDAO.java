package dao;

import model.Appointment;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {

    // Method to add a new appointment to the database
    public static void addAppointment(Appointment a) throws SQLException {
        // SQL query to insert appointment data
        String sql = "INSERT INTO Appointments (studentName, counselorId, date, time, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             PreparedStatement ps = conn.prepareStatement(sql)) {    // Create prepared statement
            // Set parameters for the prepared statement
            ps.setString(1, a.getStudentName());
            ps.setInt(2, a.getCounselorId());
            ps.setString(3, a.getDate());
            ps.setString(4, a.getTime());
            ps.setString(5, a.getStatus());
            ps.executeUpdate();  // Execute the insert operation
        }
    }

    // Method to update an existing appointment in the database
    public static void updateAppointment(Appointment a) throws SQLException {
        // SQL query to update appointment data
        String sql = "UPDATE Appointments SET studentName=?, counselorId=?, date=?, time=?, status=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             PreparedStatement ps = conn.prepareStatement(sql)) {  // Create prepared statement
            // Set parameters for the prepared statement
            ps.setString(1, a.getStudentName());
            ps.setInt(2, a.getCounselorId());
            ps.setString(3, a.getDate());
            ps.setString(4, a.getTime());
            ps.setString(5, a.getStatus());
            ps.setInt(6, a.getId());
            ps.executeUpdate();  // Execute the update operation
        }
    }

    // Method to delete an appointment from the database
    public static void deleteAppointment(int id) throws SQLException {
        // SQL query to delete appointment by ID
        String sql = "DELETE FROM Appointments WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             PreparedStatement ps = conn.prepareStatement(sql)) {  // Create prepared statement
            ps.setInt(1, id);  // Set the ID parameter
            ps.executeUpdate();  // Execute the delete operation
        }
    }

    // Method to retrieve all appointments from the database
    public static List<Appointment> getAllAppointments() throws SQLException {
        List<Appointment> list = new ArrayList<>();  // Create list to store appointments
        String sql = "SELECT * FROM Appointments";  // SQL query to select all appointments
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             Statement stmt = conn.createStatement();             // Create statement
             ResultSet rs = stmt.executeQuery(sql)) {             // Execute query and get result set
            // Iterate through the result set
            while (rs.next()) {
                // Create Appointment objects from result set data and add to list
                list.add(new Appointment(
                        rs.getInt("id"),
                        rs.getString("studentName"),
                        rs.getInt("counselorId"),
                        rs.getString("date"),
                        rs.getString("time"),
                        rs.getString("status")));
            }
        }
        return list;  // Return the list of appointments
    }

    // Method to check if a time slot is already taken by a counselor
    public static boolean isSlotTaken(int counselorId, String date, String time) throws SQLException {
        // SQL query to count appointments matching the criteria
        String sql = "SELECT COUNT(*) FROM Appointments WHERE counselorId = ? AND date = ? AND time = ?";
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             PreparedStatement ps = conn.prepareStatement(sql)) {  // Create prepared statement
            // Set parameters for the prepared statement
            ps.setInt(1, counselorId);
            ps.setString(2, date);
            ps.setString(3, time);
            ResultSet rs = ps.executeQuery();  // Execute the query
            if (rs.next()) {
                // Return true if count is greater than 0 (slot is taken)
                return rs.getInt(1) > 0;
            }
        }
        return false;  // Return false if slot is available
    }
}


