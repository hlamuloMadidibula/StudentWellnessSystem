package dao;

import java.sql.*;

public class SetupTables {

    // Method to ensure all required tables exist in the database
    public static void ensureTablesExist() {
        try (Connection conn = DatabaseConnection.getConnection()) {  // Get database connection
            DatabaseMetaData meta = conn.getMetaData();  // Get database metadata

            // ==== COUNSELORS TABLE ====
            // Check if COUNSELORS table exists
            ResultSet rs1 = meta.getTables(null, null, "COUNSELORS", null);
            if (!rs1.next()) {
                // SQL to create COUNSELORS table if it doesn't exist
                String sql = """
                    CREATE TABLE Counselors (
                        id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        specialization VARCHAR(100),
                        availability VARCHAR(100)
                    )
                """;
                conn.createStatement().executeUpdate(sql);  // Execute table creation
                System.out.println("Created table: Counselors");  // Log creation
            }

            // ==== APPOINTMENTS TABLE ====
            // Check if APPOINTMENTS table exists
            ResultSet rs2 = meta.getTables(null, null, "APPOINTMENTS", null);
            if (!rs2.next()) {
                // SQL to create APPOINTMENTS table if it doesn't exist
                String createAppointments = """
                    CREATE TABLE Appointments (
                        id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                        studentName VARCHAR(100) NOT NULL,
                        counselorId INT NOT NULL,
                        date VARCHAR(20) NOT NULL,
                        time VARCHAR(20) NOT NULL,
                        status VARCHAR(50) NOT NULL
                    )
                """;
                conn.createStatement().executeUpdate(createAppointments);  // Execute table creation
                System.out.println("Created table: Appointments");  // Log creation
            } else {
                // Check and add missing columns to existing APPOINTMENTS table

                // Check for studentName column
                ResultSet col1 = meta.getColumns(null, null, "APPOINTMENTS", "STUDENTNAME");
                if (!col1.next()) {
                    conn.createStatement().executeUpdate(
                        "ALTER TABLE Appointments ADD studentName VARCHAR(100) DEFAULT 'Unknown'"
                    );
                    System.out.println("Added column: studentName");  // Log column addition
                }

                // Check for counselorId column
                ResultSet col2 = meta.getColumns(null, null, "APPOINTMENTS", "COUNSELORID");
                if (!col2.next()) {
                    conn.createStatement().executeUpdate(
                        "ALTER TABLE Appointments ADD counselorId INT DEFAULT 0"
                    );
                    System.out.println("Added column: counselorId");  // Log column addition
                }
            }

            // ==== FEEDBACK TABLE ====
            // Check if FEEDBACK table exists
            ResultSet rs3 = meta.getTables(null, null, "FEEDBACK", null);
            if (!rs3.next()) {
                // SQL to create FEEDBACK table if it doesn't exist
                String sql = """
                    CREATE TABLE Feedback (
                        id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                        studentName VARCHAR(100),
                        rating INT,
                        comment VARCHAR(255)
                    )
                """;
                conn.createStatement().executeUpdate(sql);  // Execute table creation
                System.out.println("Created table: Feedback");  // Log creation
            }

        } catch (SQLException e) {
            e.printStackTrace();  // Print stack trace if error occurs
            System.err.println("Error in SetupTables: " + e.getMessage());  // Log error message
        }
    }
}





