package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // Database URL for Derby database
    private static final String URL = "jdbc:derby:StudentWellnessDB; create = true";

    // Method to get a database connection
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);  // Create and return connection using DriverManager
    }
}



