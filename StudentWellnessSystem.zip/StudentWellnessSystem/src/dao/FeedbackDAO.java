package dao;

import model.Feedback;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FeedbackDAO {
    // Method to add new feedback to the database
    public static void addFeedback(Feedback f) throws SQLException {
        // SQL query to insert feedback data
        String sql = "INSERT INTO Feedback (studentName, rating, comment) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             PreparedStatement ps = conn.prepareStatement(sql)) {  // Create prepared statement
            // Set parameters for the prepared statement
            ps.setString(1, f.getStudentName());
            ps.setInt(2, f.getRating());
            ps.setString(3, f.getComment());
            ps.executeUpdate();  // Execute the insert operation
        }
    }

    // Method to update existing feedback in the database
    public static void updateFeedback(Feedback f) throws SQLException {
        // SQL query to update feedback data
        String sql = "UPDATE Feedback SET studentName=?, rating=?, comment=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             PreparedStatement ps = conn.prepareStatement(sql)) {  // Create prepared statement
            // Set parameters for the prepared statement
            ps.setString(1, f.getStudentName());
            ps.setInt(2, f.getRating());
            ps.setString(3, f.getComment());
            ps.setInt(4, f.getId());
            ps.executeUpdate();  // Execute the update operation
        }
    }

    // Method to delete feedback from the database
    public static void deleteFeedback(int id) throws SQLException {
        // SQL query to delete feedback by ID
        String sql = "DELETE FROM Feedback WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             PreparedStatement ps = conn.prepareStatement(sql)) {  // Create prepared statement
            ps.setInt(1, id);  // Set the ID parameter
            ps.executeUpdate();  // Execute the delete operation
        }
    }

    // Method to retrieve all feedback from the database
    public static List<Feedback> getAllFeedback() throws SQLException {
        List<Feedback> list = new ArrayList<>();  // Create list to store feedback
        String sql = "SELECT * FROM Feedback";   // SQL query to select all feedback
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             Statement stmt = conn.createStatement();              // Create statement
             ResultSet rs = stmt.executeQuery(sql)) {             // Execute query and get result set
            // Iterate through the result set
            while (rs.next()) {
                // Create Feedback objects from result set data and add to list
                list.add(new Feedback(
                        rs.getInt("id"),
                        rs.getString("studentName"),
                        rs.getInt("rating"),
                        rs.getString("comment")));
            }
        }
        return list;  // Return the list of feedback
    }
}


