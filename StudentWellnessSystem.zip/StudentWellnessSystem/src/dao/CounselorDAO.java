package dao;

import model.Counselor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CounselorDAO {
    // Method to add a new counselor to the database
    public static void addCounselor(Counselor c) throws SQLException {
        // SQL query to insert counselor data
        String sql = "INSERT INTO Counselors (name, specialization, availability) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             PreparedStatement ps = conn.prepareStatement(sql)) {  // Create prepared statement
            // Set parameters for the prepared statement
            ps.setString(1, c.getName());
            ps.setString(2, c.getSpecialization());
            ps.setString(3, c.getAvailability());
            ps.executeUpdate();  // Execute the insert operation
        }
    }

    // Method to update an existing counselor in the database
    public static void updateCounselor(Counselor c) throws SQLException {
        // SQL query to update counselor data
        String sql = "UPDATE Counselors SET name=?, specialization=?, availability=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             PreparedStatement ps = conn.prepareStatement(sql)) {  // Create prepared statement
            // Set parameters for the prepared statement
            ps.setString(1, c.getName());
            ps.setString(2, c.getSpecialization());
            ps.setString(3, c.getAvailability());
            ps.setInt(4, c.getId());
            ps.executeUpdate();  // Execute the update operation
        }
    }

    // Method to delete a counselor from the database
    public static void deleteCounselor(int id) throws SQLException {
        // SQL query to delete counselor by ID
        String sql = "DELETE FROM Counselors WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             PreparedStatement ps = conn.prepareStatement(sql)) {  // Create prepared statement
            ps.setInt(1, id);  // Set the ID parameter
            ps.executeUpdate();  // Execute the delete operation
        }
    }

    // Method to retrieve all counselors from the database
    public static List<Counselor> getAllCounselors() throws SQLException {
        List<Counselor> list = new ArrayList<>();  // Create list to store counselors
        String sql = "SELECT * FROM Counselors";  // SQL query to select all counselors
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             Statement stmt = conn.createStatement();             // Create statement
             ResultSet rs = stmt.executeQuery(sql)) {            // Execute query and get result set
            // Iterate through the result set
            while (rs.next()) {
                // Create Counselor objects from result set data and add to list
                list.add(new Counselor(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("specialization"),
                        rs.getString("availability")));
            }
        }
        return list;  // Return the list of counselors
    }

    // Method to retrieve a counselor by their ID
    public static Counselor getCounselorById(int id) throws SQLException {
        // SQL query to select counselor by ID
        String sql = "SELECT * FROM Counselors WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();  // Get database connection
             PreparedStatement ps = conn.prepareStatement(sql)) {  // Create prepared statement
            ps.setInt(1, id);  // Set the ID parameter
            try (ResultSet rs = ps.executeQuery()) {  // Execute query and get result set
                if (rs.next()) {
                    // Create and return Counselor object if found
                    return new Counselor(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("specialization"),
                            rs.getString("availability"));
                }
            }
        }
        return null;  // Return null if no counselor found with the given ID
    }

    // Method to get counselor ID by name (currently not implemented)
    public static int getCounselorIdByName(String counselorName) {
        throw new UnsupportedOperationException("Not supported yet.");  // Placeholder for future implementation
    }
}



