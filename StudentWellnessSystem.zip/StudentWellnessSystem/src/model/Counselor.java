package model;

// Class representing a counselor
public class Counselor {

    // Declaration of private fields
    private int id;                      // Unique ID for the counselor
    private String name;                 // Name of the counselor
    private String specialization;       // Area of specialization
    private String availability;         // Availability status (e.g., Available, Busy)

    // Default constructor (no-argument)
    public Counselor() {}

    // Constructor without ID (used before storing in DB)
    public Counselor(String name, String specialization, String availability) {
        // Initializing attributes with constructor parameters
        this.name = name;
        this.specialization = specialization;
        this.availability = availability;
    }

    // Constructor with ID (used when retrieving from DB)
    public Counselor(int id, String name, String specialization, String availability) {
        // Initializing all attributes including ID
        this.id = id;
        this.name = name;
        this.specialization = specialization;
        this.availability = availability;
    }

    // Getter and Setter methods

    public int getId() {
        return id; // Returns counselor ID
    }

    public void setId(int id) {
        this.id = id; // Sets counselor ID
    }

    public String getName() {
        return name; // Returns counselor name
    }

    public void setName(String name) {
        this.name = name; // Sets counselor name
    }

    public String getSpecialization() {
        return specialization; // Returns counselor specialization
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization; // Sets specialization
    }

    public String getAvailability() {
        return availability; // Returns counselor availability
    }

    public void setAvailability(String availability) {
        this.availability = availability; // Sets availability
    }

    @Override
    public String toString() {
        return name; // Returns the name of the counselor (used when displaying in dropdown lists)
    }
}


