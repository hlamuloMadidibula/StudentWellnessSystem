package model;

// Class representing an appointment
public class Appointment {

    // Declaration of private fields
    private int id;                     // Unique identifier for the appointment
    private String studentName;        // Name of the student booking the appointment
    private int counselorId;           // ID of the counselor for the appointment
    private String date;               // Date of the appointment
    private String time;               // Time of the appointment
    private String status;             // Status (e.g., Scheduled, Completed, Cancelled)

    // Default constructor (no-argument)
    public Appointment() {}

    // Constructor without ID (usually used before inserting into the database)
    public Appointment(String studentName, int counselorId, String date, String time, String status) {
        // Initializing attributes with constructor parameters
        this.studentName = studentName;
        this.counselorId = counselorId;
        this.date = date;
        this.time = time;
        this.status = status;
    }

    // Constructor with ID (usually used when fetching from the database)
    public Appointment(int id, String studentName, int counselorId, String date, String time, String status) {
        // Initializing all attributes including ID
        this.id = id;
        this.studentName = studentName;
        this.counselorId = counselorId;
        this.date = date;
        this.time = time;
        this.status = status;
    }

    // Getter and Setter methods

    public int getId() {
        return id; // Returns appointment ID
    }

    public void setId(int id) {
        this.id = id; // Sets appointment ID
    }

    public String getStudentName() {
        return studentName; // Returns student name
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName; // Sets student name
    }

    public int getCounselorId() {
        return counselorId; // Returns counselor ID
    }

    public void setCounselorId(int counselorId) {
        this.counselorId = counselorId; // Sets counselor ID
    }

    public String getDate() {
        return date; // Returns date of appointment
    }

    public void setDate(String date) {
        this.date = date; // Sets date of appointment
    }

    public String getTime() {
        return time; // Returns time of appointment
    }

    public void setTime(String time) {
        this.time = time; // Sets time of appointment
    }

    public String getStatus() {
        return status; // Returns status of appointment
    }

    public void setStatus(String status) {
        this.status = status; // Sets status of appointment
    }
}


