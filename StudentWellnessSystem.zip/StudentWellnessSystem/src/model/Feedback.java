package model;

// Class representing feedback given by a student
public class Feedback {

    // Declaration of private fields
    private int id;                      // Unique ID for the feedback entry
    private String studentName;         // Name of the student providing feedback
    private int rating;                 // Numerical rating given (e.g., 1-5 stars)
    private String comment;             // Additional comment or message

    // Default constructor (no-argument)
    public Feedback() {}

    // Constructor without ID (used before storing in DB)
    public Feedback(String studentName, int rating, String comment) {
        // Initializing attributes with constructor parameters
        this.studentName = studentName;
        this.rating = rating;
        this.comment = comment;
    }

    // Constructor with ID (used when retrieving from DB)
    public Feedback(int id, String studentName, int rating, String comment) {
        // Initializing all attributes including ID
        this.id = id;
        this.studentName = studentName;
        this.rating = rating;
        this.comment = comment;
    }

    // Getter and Setter methods

    public int getId() {
        return id; // Returns feedback ID
    }

    public void setId(int id) {
        this.id = id; // Sets feedback ID
    }

    public String getStudentName() {
        return studentName; // Returns name of student giving feedback
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName; // Sets student name
    }

    public int getRating() {
        return rating; // Returns numerical rating
    }

    public void setRating(int rating) {
        this.rating = rating; // Sets rating value
    }

    public String getComment() {
        return comment; // Returns feedback comment
    }

    public void setComment(String comment) {
        this.comment = comment; // Sets comment text
    }
}



