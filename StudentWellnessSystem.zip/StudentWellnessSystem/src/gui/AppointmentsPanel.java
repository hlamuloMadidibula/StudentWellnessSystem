package gui;

import dao.AppointmentDAO;
import dao.CounselorDAO;
import model.Appointment;
import model.Counselor;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class AppointmentsPanel extends JPanel {
    // Form input fields
    private JTextField studentField;
    private JComboBox<Counselor> counselorBox;
    private JComboBox<String> timeBox;
    private JTextField dateField;
    private JComboBox<String> statusBox;
    private JTable table;  // Table to display appointments
    private DefaultTableModel model;  // Table model for appointments data

    public AppointmentsPanel() {
        setLayout(new BorderLayout());  // Set main panel layout

        // ===== Header Panel =====
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setBackground(new Color(240, 248, 255));  // Light blue background
        JLabel logo = new JLabel(new ImageIcon(getClass().getResource("/icons/logo.png")));
        JLabel title = new JLabel("Appointments Management");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(new Color(220, 20, 60));  // Crimson red color
        headerPanel.add(logo);
        headerPanel.add(Box.createRigidArea(new Dimension(10, 0)));  // Spacer
        headerPanel.add(title);
        add(headerPanel, BorderLayout.NORTH);  // Add header to top of panel

        // ===== Form Panel =====
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));  // 6 rows, 2 columns
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Book Appointment", TitledBorder.LEFT, TitledBorder.TOP));
        formPanel.setBackground(new Color(240, 248, 255));

        // Initialize form components
        studentField = new JTextField();
        counselorBox = new JComboBox<>();
        timeBox = new JComboBox<>(new String[]{"08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00"});
        dateField = new JTextField();
        statusBox = new JComboBox<>(new String[]{"Scheduled", "Completed", "Cancelled"});

        // Add form components with labels
        formPanel.add(new JLabel("Student Name:")); formPanel.add(studentField);
        formPanel.add(new JLabel("Counselor:")); formPanel.add(counselorBox);
        formPanel.add(new JLabel("Date (yyyy-MM-dd):")); formPanel.add(dateField);
        formPanel.add(new JLabel("Time:")); formPanel.add(timeBox);
        formPanel.add(new JLabel("Status:")); formPanel.add(statusBox);

        // ===== Buttons Panel =====
        JButton addBtn = new JButton("Add", new ImageIcon(getClass().getResource("/icons/add.png")));
        JButton updateBtn = new JButton("Update", new ImageIcon(getClass().getResource("/icons/edit.png")));
        JButton deleteBtn = new JButton("Delete", new ImageIcon(getClass().getResource("/icons/delete.png")));
        Color pink = new Color(255, 105, 180);  // Hot pink color
        
        // Style all buttons
        for (JButton btn : new JButton[]{addBtn, updateBtn, deleteBtn}) {
            btn.setBackground(pink);
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setFont(new Font("Arial", Font.BOLD, 13));
        }
        
        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(240, 248, 255));
        btnPanel.add(addBtn); btnPanel.add(updateBtn); btnPanel.add(deleteBtn);

        // Combine form and buttons
        JPanel top = new JPanel(new BorderLayout());
        top.add(formPanel, BorderLayout.CENTER);
        top.add(btnPanel, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);

        // ===== Table Setup =====
        model = new DefaultTableModel(new String[]{"ID", "Student", "Counselor", "Date", "Time", "Status"}, 0);
        table = new JTable(model);
        // Style table header
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(220, 20, 60));
        table.getTableHeader().setForeground(Color.WHITE);

        // Custom cell renderer for status colors
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (column == 5) {  // Status column
                    String status = table.getValueAt(row, 5).toString();
                    switch (status) {
                        case "Completed": c.setForeground(new Color(0, 128, 0)); break;  // Green
                        case "Cancelled": c.setForeground(Color.RED); break;
                        default: c.setForeground(Color.BLACK); break;
                    }
                } else {
                    c.setForeground(Color.BLACK);
                }
                return c;
            }
        });

        add(new JScrollPane(table), BorderLayout.CENTER);  // Add scrollable table

        // ===== Load Initial Data =====
        loadCounselorsIntoDropdown();  // Populate counselor dropdown
        loadAppointments();  // Load appointment data into table

        // ===== Event Listeners =====
        addBtn.addActionListener(e -> addAppointment());  // Add appointment button
        updateBtn.addActionListener(e -> updateAppointment());  // Update appointment button
        deleteBtn.addActionListener(e -> deleteAppointment());  // Delete appointment button
        table.getSelectionModel().addListSelectionListener(e -> populateFields());  // Row selection
    }

    // Load all counselors into the dropdown
    public void loadCounselorsIntoDropdown() {
        counselorBox.removeAllItems();  // Clear existing items
        try {
            List<Counselor> list = CounselorDAO.getAllCounselors();
            for (Counselor c : list) {
                counselorBox.addItem(c);  // Add each counselor to dropdown
            }
        } catch (SQLException e) {
            showError("Failed to load counselors: " + e.getMessage());
        }
    }

    // Load all appointments into the table
    public void loadAppointments() {
        try {
            model.setRowCount(0);  // Clear existing rows
            List<Appointment> list = AppointmentDAO.getAllAppointments();
            for (Appointment a : list) {
                Counselor c = CounselorDAO.getCounselorById(a.getCounselorId());
                model.addRow(new Object[]{  // Add each appointment as a row
                        a.getId(), a.getStudentName(), c != null ? c.getName() : "Unknown", 
                        a.getDate(), a.getTime(), a.getStatus()
                });
            }
        } catch (SQLException e) {
            showError(e.getMessage());
        }
    }

    // Add a new appointment
    private void addAppointment() {
        try {
            // Get form values
            String student = studentField.getText().trim();
            Counselor selected = (Counselor) counselorBox.getSelectedItem();
            String dateStr = dateField.getText().trim();
            String time = (String) timeBox.getSelectedItem();
            String status = (String) statusBox.getSelectedItem();

            // Validate required fields
            if (student.isEmpty() || selected == null || dateStr.isEmpty()) {
                showError("All fields are required.");
                return;
            }

            // Validate date is in future
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            LocalDateTime appointmentDateTime = LocalDateTime.parse(dateStr + " " + time, dtf);
            if (appointmentDateTime.isBefore(LocalDateTime.now())) {
                showError("Cannot book an appointment in the past.");
                return;
            }

            // Check if time slot is available
            if (AppointmentDAO.isSlotTaken(selected.getId(), dateStr, time)) {
                showError("This time slot is already taken for the selected counselor.");
                return;
            }

            // Add appointment to database
            AppointmentDAO.addAppointment(new Appointment(student, selected.getId(), dateStr, time, status));
            loadAppointments();  // Refresh table
            clearForm();  // Clear form
        } catch (Exception e) {
            showError("Invalid input or error: " + e.getMessage());
        }
    }

    // Update existing appointment
    private void updateAppointment() {
        int row = table.getSelectedRow();
        if (row == -1) {  // No row selected
            showError("Select an appointment to update.");
            return;
        }

        try {
            int id = (int) model.getValueAt(row, 0);  // Get ID from selected row
            // Get form values
            String student = studentField.getText().trim();
            Counselor selected = (Counselor) counselorBox.getSelectedItem();
            String dateStr = dateField.getText().trim();
            String time = (String) timeBox.getSelectedItem();
            String status = (String) statusBox.getSelectedItem();

            // Validate required fields
            if (student.isEmpty() || selected == null || dateStr.isEmpty()) {
                showError("All fields are required.");
                return;
            }

            // Update appointment in database
            AppointmentDAO.updateAppointment(new Appointment(id, student, selected.getId(), dateStr, time, status));
            loadAppointments();  // Refresh table
            clearForm();  // Clear form
        } catch (Exception e) {
            showError("Error updating appointment: " + e.getMessage());
        }
    }

    // Delete appointment
    private void deleteAppointment() {
        int row = table.getSelectedRow();
        if (row == -1) {  // No row selected
            showError("Select an appointment to delete.");
            return;
        }

        // Confirm deletion
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete this appointment?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                int id = (int) model.getValueAt(row, 0);  // Get ID from selected row
                AppointmentDAO.deleteAppointment(id);  // Delete from database
                loadAppointments();  // Refresh table
                clearForm();  // Clear form
            } catch (SQLException e) {
                showError(e.getMessage());
            }
        }
    }

    // Populate form fields from selected table row
    private void populateFields() {
        int row = table.getSelectedRow();
        if (row != -1) {
            studentField.setText(model.getValueAt(row, 1).toString());
            dateField.setText(model.getValueAt(row, 3).toString());
            timeBox.setSelectedItem(model.getValueAt(row, 4).toString());
            statusBox.setSelectedItem(model.getValueAt(row, 5).toString());
        }
    }

    // Clear form fields
    private void clearForm() {
        studentField.setText("");
        dateField.setText("");
        timeBox.setSelectedIndex(0);
        statusBox.setSelectedIndex(0);
        table.clearSelection();  // Deselect any selected row
    }

    // Show error message dialog
    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}





