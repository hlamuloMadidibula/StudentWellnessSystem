package gui;

import dao.CounselorDAO;
import model.Counselor;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class CounselorsPanel extends JPanel {
    // Form input fields
    private JTextField nameField;
    private JComboBox<String> specializationBox, availabilityBox;
    private JTable table;  // Table to display counselors
    private DefaultTableModel model;  // Table model for counselors data

    public CounselorsPanel() {
        setLayout(new BorderLayout());  // Set main panel layout

        // ===== Header Panel =====
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setBackground(new Color(240, 248, 255));  // Light blue background
        JLabel logo = new JLabel(new ImageIcon(getClass().getResource("/icons/logo.png")));
        JLabel title = new JLabel("Counselor Management");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(new Color(220, 20, 60));  // Crimson red color
        headerPanel.add(logo);
        headerPanel.add(Box.createRigidArea(new Dimension(10, 0)));  // Spacer
        headerPanel.add(title);
        add(headerPanel, BorderLayout.NORTH);  // Add header to top of panel

        // ===== Form Panel =====
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));  // 4 rows, 2 columns
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Add/Edit Counselor",
                TitledBorder.LEFT, TitledBorder.TOP));
        formPanel.setBackground(new Color(240, 248, 255));

        // Initialize form components
        nameField = new JTextField();
        specializationBox = new JComboBox<>(new String[]{"Psychology", "Career Guidance", "Academic Support", "Wellness"});
        availabilityBox = new JComboBox<>(new String[]{"Weekdays", "Weekends", "Mornings", "Afternoons"});

        // Add form components with labels
        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Specialization:"));
        formPanel.add(specializationBox);
        formPanel.add(new JLabel("Availability:"));
        formPanel.add(availabilityBox);

        // ===== Buttons Panel =====
        JButton addBtn = new JButton("Add", new ImageIcon(getClass().getResource("/icons/add.png")));
        JButton updateBtn = new JButton("Update", new ImageIcon(getClass().getResource("/icons/edit.png")));
        JButton deleteBtn = new JButton("Delete", new ImageIcon(getClass().getResource("/icons/delete.png")));
        Color pink = new Color(255, 105, 180);  // Hot pink color
        
        // Style all buttons
        for (JButton btn : new JButton[]{addBtn, updateBtn, deleteBtn}) {
            btn.setBackground(pink);
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setFont(new Font("Arial", Font.BOLD, 13));
        }

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(240, 248, 255));
        btnPanel.add(addBtn);
        btnPanel.add(updateBtn);
        btnPanel.add(deleteBtn);

        // Combine form and buttons
        JPanel top = new JPanel(new BorderLayout());
        top.add(formPanel, BorderLayout.CENTER);
        top.add(btnPanel, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);

        // ===== Table Setup =====
        model = new DefaultTableModel(new String[]{"ID", "Name", "Specialization", "Availability"}, 0);
        table = new JTable(model);
        // Style table header
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(220, 20, 60));
        table.getTableHeader().setForeground(Color.WHITE);

        add(new JScrollPane(table), BorderLayout.CENTER);  // Add scrollable table

        // ===== Load Initial Data =====
        loadCounselors();  // Load counselor data into table

        // ===== Event Listeners =====
        addBtn.addActionListener(e -> addCounselor());  // Add counselor button
        updateBtn.addActionListener(e -> updateCounselor());  // Update counselor button
        deleteBtn.addActionListener(e -> deleteCounselor());  // Delete counselor button
        table.getSelectionModel().addListSelectionListener(e -> populateFields());  // Row selection
    }

    // Load all counselors into the table
    private void loadCounselors() {
        model.setRowCount(0);  // Clear existing rows
        try {
            List<Counselor> list = CounselorDAO.getAllCounselors();
            for (Counselor c : list) {
                model.addRow(new Object[]{  // Add each counselor as a row
                        c.getId(), c.getName(), c.getSpecialization(), c.getAvailability()
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading counselors: " + e.getMessage());
        }
    }

    // Add a new counselor
    private void addCounselor() {
        // Get form values
        String name = nameField.getText().trim();
        String spec = (String) specializationBox.getSelectedItem();
        String avail = (String) availabilityBox.getSelectedItem();

        // Validate required field
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in the counselor name.");
            return;
        }

        try {
            CounselorDAO.addCounselor(new Counselor(name, spec, avail));  // Add to database
            loadCounselors();  // Refresh table
            clearForm();  // Clear form
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error adding counselor: " + e.getMessage());
        }
        MainApp.getInstance().refreshAppointmentsDropdown();  // Update appointments dropdown
    }

    // Update existing counselor
    private void updateCounselor() {
        int row = table.getSelectedRow();
        if (row == -1) {  // No row selected
            JOptionPane.showMessageDialog(this, "Select a counselor to update.");
            return;
        }

        // Get values from form and selected row
        int id = (int) model.getValueAt(row, 0);
        String name = nameField.getText().trim();
        String spec = (String) specializationBox.getSelectedItem();
        String avail = (String) availabilityBox.getSelectedItem();

        // Validate required field
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in the counselor name.");
            return;
        }

        try {
            CounselorDAO.updateCounselor(new Counselor(id, name, spec, avail));  // Update in database
            loadCounselors();  // Refresh table
            clearForm();  // Clear form
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error updating counselor: " + e.getMessage());
        }
        MainApp.getInstance().refreshAppointmentsDropdown();  // Update appointments dropdown
    }

    // Delete counselor
    private void deleteCounselor() {
        int row = table.getSelectedRow();
        if (row == -1) {  // No row selected
            JOptionPane.showMessageDialog(this, "Select a counselor to delete.");
            return;
        }

        // Confirm deletion
        int id = (int) model.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete this counselor?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                CounselorDAO.deleteCounselor(id);  // Delete from database
                loadCounselors();  // Refresh table
                clearForm();  // Clear form
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting counselor: " + e.getMessage());
            }
        }
        MainApp.getInstance().refreshAppointmentsDropdown();  // Update appointments dropdown
    }

    // Populate form fields from selected table row
    private void populateFields() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        nameField.setText(model.getValueAt(row, 1).toString());
        specializationBox.setSelectedItem(model.getValueAt(row, 2).toString());
        availabilityBox.setSelectedItem(model.getValueAt(row, 3).toString());
    }

    // Clear form fields
    private void clearForm() {
        nameField.setText("");
        specializationBox.setSelectedIndex(0);
        availabilityBox.setSelectedIndex(0);
        table.clearSelection();  // Deselect any selected row
    }
}
