package gui;

import javax.swing.*;
import java.awt.*;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import dao.SetupTables;

public class MainApp extends JFrame {

// Panel that holds all card-based views
    private JPanel cardPanel;
// Dynamic label that displays current section heading
    private JLabel headingLabel;
// Stores different views (Dashboard, Appointments, etc.) mapped by name
    private Map<String, JPanel> views = new HashMap<>();
// Reference to the Appointments panel for later access
    private AppointmentsPanel appointmentsPanel; // make accessible
// Singleton instance to allow global access
    private static MainApp instance;

// Constructor for the MainApp JFrame
    public MainApp() {
        instance = this;

// Set the window title
        setTitle("BC Student Wellness System");
// Set the initial size of the window
        setSize(900, 600);
// Ensure the application exits when the window is closed
        setDefaultCloseOperation(EXIT_ON_CLOSE);
// Center the window on the screen
        setLocationRelativeTo(null);

// Create required database tables if they don't already exist
        SetupTables.ensureTablesExist();

        // ===== HEADER (logo + dynamic heading) =====
// Create top panel with FlowLayout for logo and heading
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(new Color(240, 248, 255));

        URL logoURL = getClass().getResource("/icons/logo.png");
        JLabel logoLabel = new JLabel(logoURL != null ? new ImageIcon(logoURL) : new ImageIcon());

// Create new label, most likely for text
        headingLabel = new JLabel("BC Student Wellness Dashboard");
        headingLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headingLabel.setForeground(new Color(220, 20, 60));

// Add components to the top header panel
        topPanel.add(logoLabel);
// Add components to the top header panel
        topPanel.add(Box.createRigidArea(new Dimension(10, 0)));
// Add components to the top header panel
        topPanel.add(headingLabel);

        // ===== MAIN CONTENT AREA =====
// Create card layout container to switch between views
        cardPanel = new JPanel(new CardLayout());

        // Dashboard Panel
        JPanel dashboardPanel = createDashboardPanel();
// Add a view to the map with a name key
        views.put("Dashboard", dashboardPanel);

        // Appointments Panel
        appointmentsPanel = new AppointmentsPanel();
        JPanel appointmentWrapper = wrapWithBackButton(appointmentsPanel, "Appointments");
// Add a view to the map with a name key
        views.put("Appointments", appointmentWrapper);

        // Counselors Panel
        CounselorsPanel counselorsPanel = new CounselorsPanel();
        JPanel counselorWrapper = wrapWithBackButton(counselorsPanel, "Counselors");
// Add a view to the map with a name key
        views.put("Counselors", counselorWrapper);

        // Feedback Panel
        FeedbackPanel feedbackPanel = new FeedbackPanel();
        JPanel feedbackWrapper = wrapWithBackButton(feedbackPanel, "Feedback");
// Add a view to the map with a name key
        views.put("Feedback", feedbackWrapper);

        // Add all views
// Add all views from the map to the card panel
        for (String key : views.keySet()) {
            cardPanel.add(views.get(key), key);
        }

        // Layout
// Use BorderLayout for main JFrame layout
        setLayout(new BorderLayout());
// Add the top header panel to the NORTH of the frame
        add(topPanel, BorderLayout.NORTH);
// Add the card view container to the CENTER of the frame
        add(cardPanel, BorderLayout.CENTER);

        // Show first view
// Show the initial Dashboard view
        showView("Dashboard");
    }

    // ===== Refresh counselor dropdown in AppointmentsPanel =====
// Public method to reload counselor dropdown in appointment panel
    public void refreshAppointmentsDropdown() {
        if (appointmentsPanel != null) {
            appointmentsPanel.loadCounselorsIntoDropdown();
        }
    }

    // ===== Static accessor =====
// Static method to retrieve singleton MainApp instance
    public static MainApp getInstance() {
        return instance;
    }

    // ===== Show view =====
// Show the initial Dashboard view
    private void showView(String name) {
        ((CardLayout) cardPanel.getLayout()).show(cardPanel, name);
        headingLabel.setText("BC Student Wellness " + name);
        if ("Appointments".equals(name)) {
            appointmentsPanel.loadCounselorsIntoDropdown();
        }
    }

    // ===== Dashboard =====
    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel();
// Use BorderLayout for main JFrame layout
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(240, 248, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

// Create new label, most likely for text
        JLabel welcomeLabel = new JLabel("Welcome to BC Student Wellness System!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 22));
        welcomeLabel.setForeground(new Color(0, 102, 204));
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

// Create new label, most likely for text
        JLabel infoLabel = new JLabel("What would you like to do today?");
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        infoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        infoLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));

        JButton btnAppointments = new JButton("Book Appointment");
        JButton btnCounselors = new JButton("Manage Counselors");
        JButton btnFeedback = new JButton("Submit/View Feedback");

        for (JButton btn : new JButton[]{btnAppointments, btnCounselors, btnFeedback}) {
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            btn.setMaximumSize(new Dimension(250, 40));
            btn.setBackground(new Color(255, 105, 180));
            btn.setForeground(Color.WHITE);
            btn.setFont(new Font("Arial", Font.BOLD, 14));
            btn.setFocusPainted(false);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        }

// Show the initial Dashboard view
        btnAppointments.addActionListener(e -> showView("Appointments"));
// Show the initial Dashboard view
        btnCounselors.addActionListener(e -> showView("Counselors"));
// Show the initial Dashboard view
        btnFeedback.addActionListener(e -> showView("Feedback"));

        panel.add(welcomeLabel);
        panel.add(infoLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(btnAppointments);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(btnCounselors);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(btnFeedback);

        return panel;
    }

    // ===== Wrap with back button =====
    private JPanel wrapWithBackButton(JPanel mainContent, String name) {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(new Color(240, 248, 255));

        JButton back = new JButton("← Back to Dashboard");
        back.setFont(new Font("Arial", Font.PLAIN, 13));
        back.setBackground(Color.LIGHT_GRAY);
        back.setFocusPainted(false);
// Show the initial Dashboard view
        back.addActionListener(e -> showView("Dashboard"));

        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topBar.setBackground(new Color(240, 248, 255));
        topBar.add(back);

        wrapper.add(topBar, BorderLayout.NORTH);
        wrapper.add(mainContent, BorderLayout.CENTER);
        return wrapper;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainApp().setVisible(true));
    }
}







