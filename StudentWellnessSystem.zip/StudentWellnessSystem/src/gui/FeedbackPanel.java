package gui;

import dao.FeedbackDAO;
import model.Feedback;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class FeedbackPanel extends JPanel {
    // Form input fields
    private JTextField studentField;
    private JComboBox<String> ratingBox;
    private JTextArea commentArea;
    private JTable table;  // Table to display feedback
    private DefaultTableModel model;  // Table model for feedback data

    public FeedbackPanel() {
        setLayout(new BorderLayout());  // Set main panel layout

        // ===== Header Panel =====
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setBackground(new Color(240, 248, 255));  // Light blue background
        JLabel logo = new JLabel(new ImageIcon(getClass().getResource("/icons/logo.png")));
        JLabel title = new JLabel("Feedback Management");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(new Color(220, 20, 60));  // Crimson red color
        headerPanel.add(logo);
        headerPanel.add(Box.createRigidArea(new Dimension(10, 0)));  // Spacer
        headerPanel.add(title);
        add(headerPanel, BorderLayout.NORTH);  // Add header to top of panel

        // ===== Split Panel Layout =====
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(400);  // Set initial divider position

        // ===== Form Panel (Left Side) =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Submit Feedback",
                TitledBorder.LEFT, TitledBorder.TOP));
        formPanel.setBackground(new Color(240, 248, 255));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);  // Padding
        gbc.fill = GridBagConstraints.HORIZONTAL;  // Horizontal component fill

        // Student name field
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Student Name:"), gbc);
        gbc.gridx = 1;
        studentField = new JTextField();
        formPanel.add(studentField, gbc);

        // Rating dropdown
        gbc.gridx = 0; gbc.gridy++;
        formPanel.add(new JLabel("Rating (1–5):"), gbc);
        gbc.gridx = 1;
        ratingBox = new JComboBox<>(new String[]{"1", "2", "3", "4", "5"});
        formPanel.add(ratingBox, gbc);

        // Comment area with scroll
        gbc.gridx = 0; gbc.gridy++;
        formPanel.add(new JLabel("Comments:"), gbc);
        gbc.gridx = 1;
        commentArea = new JTextArea(3, 20);
        commentArea.setLineWrap(true);  // Enable line wrapping
        commentArea.setWrapStyleWord(true);  // Wrap at word boundaries
        JScrollPane commentScroll = new JScrollPane(commentArea);
        formPanel.add(commentScroll, gbc);

        // Buttons
        gbc.gridx = 0; gbc.gridy++;
        gbc.gridwidth = 2;  // Span two columns
        gbc.anchor = GridBagConstraints.CENTER;  // Center alignment

        JButton addBtn = new JButton("Submit", new ImageIcon(getClass().getResource("/icons/add.png")));
        JButton updateBtn = new JButton("Update", new ImageIcon(getClass().getResource("/icons/edit.png")));
        JButton deleteBtn = new JButton("Delete", new ImageIcon(getClass().getResource("/icons/delete.png")));
        Color pink = new Color(255, 105, 180);  // Hot pink color
        
        // Style all buttons
        for (JButton btn : new JButton[]{addBtn, updateBtn, deleteBtn}) {
            btn.setBackground(pink);
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setFont(new Font("Arial", Font.BOLD, 13));
            btn.setPreferredSize(new Dimension(100, 30));
        }

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(new Color(240, 248, 255));
        btnPanel.add(addBtn);
        btnPanel.add(updateBtn);
        btnPanel.add(deleteBtn);

        formPanel.add(btnPanel, gbc);

        splitPane.setLeftComponent(formPanel);  // Add form to left side

        // ===== Table Panel (Right Side) =====
        model = new DefaultTableModel(new String[]{"ID", "Student", "Rating", "Comment"}, 0);
        table = new JTable(model);
        // Style table header
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(220, 20, 60));
        table.getTableHeader().setForeground(Color.WHITE);

        JScrollPane tableScroll = new JScrollPane(table);
        splitPane.setRightComponent(tableScroll);  // Add table to right side

        add(splitPane, BorderLayout.CENTER);  // Add split pane to main panel

        // ===== Load Initial Data =====
        loadFeedback();  // Load feedback data into table

        // ===== Event Listeners =====
        addBtn.addActionListener(e -> submitFeedback());  // Submit feedback button
        updateBtn.addActionListener(e -> updateFeedback());  // Update feedback button
        deleteBtn.addActionListener(e -> deleteFeedback());  // Delete feedback button
        table.getSelectionModel().addListSelectionListener(e -> populateFields());  // Row selection
    }

    // Load all feedback into the table
    private void loadFeedback() {
        model.setRowCount(0);  // Clear existing rows
        try {
            List<Feedback> list = FeedbackDAO.getAllFeedback();
            for (Feedback f : list) {
                model.addRow(new Object[]{  // Add each feedback as a row
                        f.getId(), f.getStudentName(), f.getRating(), f.getComment()
                });
            }
        } catch (SQLException e) {
            showError("Error loading feedback: " + e.getMessage());
        }
    }

    // Submit new feedback
    private void submitFeedback() {
        // Get form values
        String name = studentField.getText().trim();
        String rating = (String) ratingBox.getSelectedItem();
        String comment = commentArea.getText().trim();

        // Validate required fields
        if (name.isEmpty() || comment.isEmpty()) {
            showError("Please fill in all fields.");
            return;
        }

        try {
            FeedbackDAO.addFeedback(new Feedback(name, Integer.parseInt(rating), comment));  // Add to database
            loadFeedback();  // Refresh table
            clearForm();  // Clear form
        } catch (SQLException e) {
            showError("Error submitting feedback: " + e.getMessage());
        }
    }

    // Update existing feedback
    private void updateFeedback() {
        int row = table.getSelectedRow();
        if (row == -1) {  // No row selected
            showError("Select a feedback to update.");
            return;
        }

        // Get values from form and selected row
        int id = (int) model.getValueAt(row, 0);
        String name = studentField.getText().trim();
        String rating = (String) ratingBox.getSelectedItem();
        String comment = commentArea.getText().trim();

        // Validate required fields
        if (name.isEmpty() || comment.isEmpty()) {
            showError("Please fill in all fields.");
            return;
        }

        try {
            FeedbackDAO.updateFeedback(new Feedback(id, name, Integer.parseInt(rating), comment));  // Update in database
            loadFeedback();  // Refresh table
            clearForm();  // Clear form
        } catch (SQLException e) {
            showError("Error updating feedback: " + e.getMessage());
        }
    }

    // Delete feedback
    private void deleteFeedback() {
        int row = table.getSelectedRow();
        if (row == -1) {  // No row selected
            showError("Select a feedback to delete.");
            return;
        }

        // Confirm deletion
        int id = (int) model.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete this feedback?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                FeedbackDAO.deleteFeedback(id);  // Delete from database
                loadFeedback();  // Refresh table
                clearForm();  // Clear form
            } catch (SQLException e) {
                showError("Error deleting feedback: " + e.getMessage());
            }
        }
    }

    // Populate form fields from selected table row
    private void populateFields() {
        int row = table.getSelectedRow();
        if (row != -1) {
            studentField.setText(model.getValueAt(row, 1).toString());
            ratingBox.setSelectedItem(model.getValueAt(row, 2).toString());
            commentArea.setText(model.getValueAt(row, 3).toString());
        }
    }

    // Clear form fields
    private void clearForm() {
        studentField.setText("");
        commentArea.setText("");
        ratingBox.setSelectedIndex(0);
        table.clearSelection();  // Deselect any selected row
    }

    // Show error message dialog
    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}




